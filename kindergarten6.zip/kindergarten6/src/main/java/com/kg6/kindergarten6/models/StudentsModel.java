package com.kg6.kindergarten6.models;

import jakarta.persistence.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Entity
@Table(name = "student") // table name at database
public class StudentsModel {

    //variables
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "first_name")
    private String first_name;

    private String last_name;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate dob;

    private int age;
    private String guardian_name;
    private String guardian_contact;

    // New fields for additional fees
    private boolean foodFeeSelected;
    private boolean transportFeeSelected;

    //setter

    public void setId(int id) {
        this.id = id;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setGuardian_name(String guardian_name) {
        this.guardian_name = guardian_name;
    }

    public void setGuardian_contact(String guardian_contact) {
        this.guardian_contact = guardian_contact;
    }

    // New setter methods for fee options
    public void setFoodFeeSelected(boolean foodFeeSelected) {
        this.foodFeeSelected = foodFeeSelected;
    }

    public void setTransportFeeSelected(boolean transportFeeSelected) {
        this.transportFeeSelected = transportFeeSelected;
    }

    //getter

    public int getId() {
        return id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public LocalDate getDob() {
        return dob;
    }

    public int getAge() {
        return age;
    }

    public String getGuardian_name() {
        return guardian_name;
    }

    public String getGuardian_contact() {
        return guardian_contact;
    }

    // New getter methods for fee options
    public boolean isFoodFeeSelected() {
        return foodFeeSelected;
    }

    public boolean isTransportFeeSelected() {
        return transportFeeSelected;
    }

    // Method to calculate total fees
    public double calculateTotalFees() {
        double totalFees = calculateFees(); // Base fees based on age
        if (foodFeeSelected) {
            totalFees += 50; // Add food fee
        }
        if (transportFeeSelected) {
            totalFees += 30; // Add transport fee
        }
        return totalFees;
    }

    // Method to calculate fees based on age
    public double calculateFees() {
        if (age < 3) {
            return 100; // Fee for toddlers
        } else if (age <= 5) {
            return 200; // Fee for preschoolers
        } else {
            return 300; // Fee for older children
        }
    }

    @Override
    public String toString() {
        return "StudentModel{" +
                "id=" + id +
                ", first_name='" + first_name + '\'' +
                ", last_name='" + last_name + '\'' +
                ", dob=" + dob +
                ", age=" + age +
                ", guardian_name='" + guardian_name + '\'' +
                ", guardian_contact='" + guardian_contact + '\'' +
                '}';
    }
}
