package com.kg6.kindergarten6.services;

import com.kg6.kindergarten6.models.UsersModel;
import com.kg6.kindergarten6.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsersServices {

    @Autowired
    private UsersRepository usersRepository;

    //method to register user
    public UsersModel registerUser(String login, String password, String email){

        // Validate inputs (e.g., check for empty values or invalid formats)
        if (login == null || password == null || email == null) {
            return null;
        }else {

            // Check if user with the same login or email exists
            if (usersRepository.findByLogin(login).isPresent() || usersRepository.findByEmail(email).isPresent()) {
                System.out.println("user already existed");
                return null; // Return null if the user already exists
            }

            // Save the user
            UsersModel usersModel = new UsersModel();
            usersModel.setLogin(login);
            usersModel.setPassword(password);
            usersModel.setEmail(email);
            return usersRepository.save(usersModel);
        }
    }

    //method for user to login
    public UsersModel authenticate(String login, String password){
        return usersRepository.findByLoginAndPassword(login, password).orElse(null);
    }
}
