package com.kg6.kindergarten6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kindergarten6Application {

	public static void main(String[] args) {
		SpringApplication.run(Kindergarten6Application.class, args);
	}

}
