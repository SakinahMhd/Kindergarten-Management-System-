package com.kg6.kindergarten6.controllers;

import com.kg6.kindergarten6.models.StudentsModel;
import com.kg6.kindergarten6.models.UsersModel;
import com.kg6.kindergarten6.repository.StudentsRepository;
import com.kg6.kindergarten6.services.StudentsServices;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
public class StudentsController {

    @Autowired
    private StudentsRepository studentsRepository;
    @Autowired
    private StudentsServices studentsServices;

    //fetch page to create student and input details
    @GetMapping("/create")
    public String getCreateStudentPage(Model model){
        model.addAttribute("createStudentRequest", new StudentsModel());
        return "create_student_page";
    }

    //fetch home page and pass list of students to the view
    @GetMapping("/home")
    public String getHomePage(Model model){
        System.out.println("Fetching all students");
        // Fetch all students from the service if no search was performed
        List<StudentsModel> studentsModel;

        if (model.containsAttribute("studentsModel")) {
            studentsModel = (List<StudentsModel>) model.getAttribute("studentsModel");
        } else {
            studentsModel = studentsServices.findAll();
        }

        // Add students list to model, so it can be accessed in the view
        model.addAttribute("studentsModel", studentsModel);

        // Return the view name for the home page
        return "home_page";
    }

    //create student based on provided details from form
    @PostMapping("/createStudent")
    public String createStudentData(@ModelAttribute StudentsModel studentsModel) {
        System.out.println("Student details: " + studentsModel);

        // Create the student with the new fields for food and transport fee selections
        StudentsModel createdStudent = studentsServices.createStudent(
                studentsModel.getFirst_name(),
                studentsModel.getLast_name(),
                studentsModel.getDob(),
                studentsModel.getAge(),
                studentsModel.getGuardian_name(),
                studentsModel.getGuardian_contact(),
                studentsModel.isFoodFeeSelected(), // Capture food fee selection
                studentsModel.isTransportFeeSelected() // Capture transport fee selection
        );

        return createdStudent == null ? "input_error_page" : "redirect:/home";
    }

    //delete a student data
    @PostMapping("/delete/{id}")
    public String deleteStudentData(@PathVariable int id){

        //retrieve student to confirm existence
        StudentsModel studentsModel = studentsRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid student ID: " + id));

        //delete the particular student
        studentsRepository.delete(studentsModel);

        //redirect to student list
        return "redirect:/home";
    }

    // View a student data
    @GetMapping("/view/{id}")
    public String viewStudentData(@PathVariable int id, Model model) {
        // Retrieve student to confirm existence
        StudentsModel studentsModel = studentsServices.getStudentById(id);

        // Calculate total fees based on the student's age and selected options
        double totalFees = studentsModel.calculateTotalFees();

        System.out.println("Student: " + studentsModel);

        // Add students list and total fees to model, so it can be accessed in the view
        model.addAttribute("studentsModel", studentsModel);
        model.addAttribute("calculatedFees", totalFees); // Add total fees to the model

        // Return the view name for home page
        return "view_student_page";
    }

    //fetch student edit page
    @GetMapping("/edit/{id}")
    public String editStudentData(Model model, @PathVariable int id){
        try{
            StudentsModel studentsModel = studentsServices.getStudentById(id);
            model.addAttribute("studentModel", studentsModel);

            return "edit_student_page";
        }
        catch (IllegalArgumentException e) {
            // Handle the error (for example, student not found)
            model.addAttribute("errorMessage", "Student not found with ID: " + id);
            return "input_error_page";
        }
    }

    //edit student details
    @PostMapping("/update/{id}")
    public String updateStudentData(@PathVariable int id, @ModelAttribute StudentsModel updatedStudent, Model model) {
        // Update student logic here
        studentsServices.updateStudent(id, updatedStudent);

        return "redirect:/view/" + id; // Redirect to the view page after updating
    }

    //search student name
    @GetMapping("/search")
    public String searchStudentData(@RequestParam("query") String query, Model model){

        if (query == null || query.trim().isEmpty()) {
            List<StudentsModel> studentsModel = studentsServices.findAll();
            model.addAttribute("studentsModel", studentsModel);
            return "home_page"; // Display all students
        }

        // Search for students based on the first name
        List<StudentsModel> studentsModel = studentsServices.searchByFirstName(query);
        model.addAttribute("studentsModel", studentsModel);

        // Return to home_page to display the results
        return "home_page"; // Display searched data on the homepage
    }

}
