package com.kg6.kindergarten6.repository;

import com.kg6.kindergarten6.models.StudentsModel;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface StudentsRepository extends JpaRepository<StudentsModel, Integer> {

    //method to retrieve all student data
    List<StudentsModel> findAll(Sort id);

    //method to search student by first name
    @Query("SELECT s FROM StudentsModel s WHERE LOWER(s.first_name) LIKE LOWER(CONCAT('%', :first_name, '%'))")
    List<StudentsModel> findByFirst_Name(String first_name);

}
