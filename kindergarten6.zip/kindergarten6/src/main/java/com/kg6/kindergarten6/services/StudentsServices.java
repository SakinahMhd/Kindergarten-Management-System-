package com.kg6.kindergarten6.services;

import com.kg6.kindergarten6.models.StudentsModel;
import com.kg6.kindergarten6.models.UsersModel;
import com.kg6.kindergarten6.repository.StudentsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Service
public class StudentsServices {

    @Autowired
    private StudentsRepository studentsRepository;

    //fetch all student details with sorting
    public List<StudentsModel> findAll() {
        System.out.println("Fetching all students");
        return studentsRepository.findAll(Sort.by("id"));
    }

    // Search for products by name or category
    public List<StudentsModel> searchByFirstName(String query) {
        return studentsRepository.findByFirst_Name(query);
    }

    //method to create student
    public StudentsModel createStudent(String firstName, String lastName, LocalDate dob, int age, String guardianName, String guardianContact, boolean foodFeeSelected, boolean transportFeeSelected) {
        StudentsModel student = new StudentsModel();
        student.setFirst_name(firstName);
        student.setLast_name(lastName);
        student.setDob(dob);
        student.setAge(age);
        student.setGuardian_name(guardianName);
        student.setGuardian_contact(guardianContact);
        student.setFoodFeeSelected(foodFeeSelected); // Set food fee selection
        student.setTransportFeeSelected(transportFeeSelected); // Set transport fee selection

        return studentsRepository.save(student); // Save to the database
    }

    //method to fetch student by ID
    public StudentsModel getStudentById(int id){
        return studentsRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Student not found with id: " + id));
    }

    //method to update student in database
    public void updateStudent(int id, StudentsModel updatedStudent) {
        StudentsModel existingStudent = studentsRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Student not found with id: " + id));

        existingStudent.setFirst_name(updatedStudent.getFirst_name());
        existingStudent.setLast_name(updatedStudent.getLast_name());
        existingStudent.setDob(updatedStudent.getDob());
        existingStudent.setGuardian_name(updatedStudent.getGuardian_name());
        existingStudent.setGuardian_contact(updatedStudent.getGuardian_contact());

        studentsRepository.save(existingStudent); // Save updated student
    }
}
